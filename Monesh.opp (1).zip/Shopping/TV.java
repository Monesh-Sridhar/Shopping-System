// Monesh
// R00196093
//SD2

package Shopping;


public class TV extends Product{
	 private String make;
     private String model;
     private String type;
     
     public TV(String make, String model, String type, String name,ProductDB productdb) {
    	  super(name);
    	  try {
     		 if (type == "LED" || type == "LCD")
     		 {
     			 this.make = make;
     	    	 this.model = model;
     	    	 this.type = type;
     	    	productdb.addToProduct(this);
     		 }
          }
     	 catch(Exception e) { 
     		 System.out.println("Invalid Make");
     	 }   	  
     }
     
     public TV()
     {
    	 
     }
     
     public void setMake(String make) 
 	 {
 		 this.make = make;
 	 }
      public String getMake()
 	 {
 		 return this.make;
 	 }
      public void setModel(String model) 
 	 {
 		 this.model = model;
 	 }
      public String getModel()
 	 {
 		 return this.model;
 	 }
      public void setType(String type) 
  	 {
  		 this.type = type;
  	 }
       public String getType()
  	 {
  		 return this.type;
  	 }
       public void setName(String Name) 
  	 {
  		  super.name = name;
  	 }
       public String getName()
  	 {
  		 return super.name;
  	 }
      public void Print()
       {
    	  System.out.println(this); 
       }
     public String toString()
     {
    	 return make +" " + model +" "  + type + " " + name;
     }
}
