package Shopping;
import java.util.*;
public class Customer {
       private String name;
       private String address;
       private 	ArrayList<Order> orders = new ArrayList<Order>();
       
       public Customer(String name, String address, ArrayList<Order> orders)
       {
    	   this.name = name;
    	   this.address = address;
    	   this.orders = orders;
       }
       public Customer()
       {
    	   
       }
       
       public void setName(String name) 
     	 {
     		 this.name = name;
     	 }
        public String getName()
     	 {
     		 return this.name;
     	 }
        public void setAddress(String address) 
    	 {
    		 this.address = address;
    	 }
       public String getAddress()
    	 {
    		 return this.address;
    	 }
  
       public void addOrders(Order order)
       {
     	  this.orders.add(order);
       }
       
       public void removeOrder(Order order)
       {
     	  this.orders.remove(order);
       }
       public ArrayList<Order> getAllOrder()
       {
     	  return this.orders;
       }
       
       public int find(Order order)
       {
     	  return orders.indexOf(order);
       }
}
