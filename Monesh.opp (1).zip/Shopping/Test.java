// Monesh
// R00196093
//SD2

package Shopping;


public class Test {

	public static void main(String[] args) {
		
		ProductDB p = new ProductDB();
		
	   
	    
		Phone p1 = new Phone("Nokia","SSM",100,"Note",p);
		Phone p2 = new Phone("Samsung","SSMD",10,"NotePro",p);
		Phone p3 = new Phone("Apple","DSS",500,"Pro",p);
		Phone p4 = new Phone("Nokia","SP",105,"ProMax",p);
		
		
		
		
		
		TV tv1 = new TV("Sony","Xperia","LED","Bravia",p);
		TV tv2 = new TV("Samsung","XP","LED","BraviaX",p);
		TV tv3 = new TV("Sony","Xpeeria","LCD","BraviaPro",p);
		
		
		
		OrderDetails od1 = new OrderDetails(p2,5);
		OrderDetails od2 = new OrderDetails(tv1,2);
		OrderDetails od3 = new OrderDetails(tv3,1);
		
		Order o = new Order();
		
		o.addOrder(od1);
		o.addOrder(od2);
		o.addOrder(od3);
		
		Customer  c = new Customer();
		
		c.addOrders(o);
		
		System.out.println(p.getAll().toString());
		
		
		
		
		

	}

}
