// Monesh
// R00196093
//SD2

package Shopping;

public abstract  class Product {
         private int productId;
         public static int id = 0;
         protected String name;
         private String description;
         private double price;
         
         
         public  Product (String name, String description, double price)
         {
        	 Product.id++;
        	 this.productId = Product.id;
        	 this.name = name;
        	 this.description = description;
        	 this.price = price;
         }
         
         public Product ()
         {
        	 
         }
         
         public Product(String name) {
        	 Product.id++;
        	 this.productId = Product.id;
        	 this.name = name;
         }
       
         public void setDescription(String description) 
    	 {
    		 this.description = description;
    	 }
         public String getDescription()
    	 {
    		 return this.description;
    	 }        
         public int getProductId()
    	 {
    		 return this.productId;
    	 }
         public void setPrice(double price) 
    	 {
    		 this.price = price;
    	 }
         public double getPrice()
    	 {
    		 return this.price;
    	 }
         public abstract void Print();
         
}
