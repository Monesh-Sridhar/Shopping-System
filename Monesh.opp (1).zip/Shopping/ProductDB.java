// Monesh
// R00196093
//SD2

package Shopping;
import java.util.HashMap;
public class ProductDB {
	
    private HashMap<Integer, Product> productsDB = new HashMap<Integer, Product>();
    
    public void addToProduct(Product product)
    {
    	productsDB.put(product.getProductId(), product);
    }
    
    public void removeToProduct(int productId)
    {
    	productsDB.remove(productId);
    }  
    public Product findProduct(int productId)
    {
    	return productsDB.get(productId);
    }
    
    public HashMap<Integer, Product> getAll()
    {
    	return this.productsDB;
    }
}
