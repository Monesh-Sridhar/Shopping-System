// Monesh
// R00196093
//SD2
package Shopping;

public class Phone extends Product {
         private String make;
         private String model;
         private int storage;
        
         
         public Phone(String make, String model, int storage, String name,ProductDB productdb)
         {
        	 super(name);
        	 try {
        		 if (make == "Apple" || make == "Samsung" || make == "Nokia")
        		 {
        			 this.make = make;
        			 this.model = model;
                	 this.storage = storage;
                	 productdb.addToProduct(this);
        		 }
             }
        	 catch(Exception e) { 
        		 System.out.println("Invalid Make");
        	 }
         }
         
         public Phone()
         {
        	 
         }
         
         public void setMake(String make) 
    	 {
    		 this.make = make;
    	 }
         public String getMake()
    	 {
    		 return this.make;
    	 }
         public void setModel(String model) 
    	 {
    		 this.model = model;
    	 }
         public String getModel()
    	 {
    		 return this.model;
    	 }
         public void setStorage(int storage) 
    	 {
    		 this.storage = storage;
    	 }
         public int getStorage()
    	 {
    		 return this.storage;
    	 }
         public void setName(String Name) 
    	 {
    		  super.name = Name;
    	 }
         public String getName()
    	 {
    		 return super.name;
    	 }
          public void Print()
         {
        	System.out.println(this); 
         }
          public String toString()
          {
         	 return make +" " + model +" "  + storage + " " + name;
          }
}
