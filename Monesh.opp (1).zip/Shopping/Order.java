package Shopping;
import java.util.*;

public class Order {
      private ArrayList <OrderDetails> order = new ArrayList<OrderDetails>();
      
      public Order(ArrayList <OrderDetails> order)
      {
    	  this.order = order;
      }
      
      public Order()
      {
    	  
      }
      
      public void addOrder(OrderDetails orderdetails)
      {
    	  this.order.add(orderdetails);
      }
      
      public void removeOrder(OrderDetails orderdetails)
      {
    	  this.order.remove(orderdetails);
      }
      public ArrayList<OrderDetails> getAllOrder()
      {
    	  return this.order;
      }
      
      public int find(OrderDetails orderdetails)
      {
    	  return order.indexOf(orderdetails);
      }
      
}
